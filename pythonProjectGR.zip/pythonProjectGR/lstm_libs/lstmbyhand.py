#Asignatura: IA
#Elaborado por: Gabriel Ramírez
#11/02/2023

#Basado en el script creado por  Joshua Starmer en el tutorial Gran memoria a largo plazo (LSTM) con PyTorch + Lightning https://youtu.be/RHGiXPuo_pI

#NOTA: Este script utiliza La Programación Orientada a Objetos (POO u OOP según sus siglas en inglés) como paradigma de programación que usa objetos y sus interacciones para diseñar aplicaciones y programas
#En el script se pueden encontrar definición de Clases (usando la palabra reservada class), Objetos como instancias  model = BasicNN() y Métodos usando la palabra reservada def

#Importar los módulos que harán todo el trabajo
import torch # torch nos permitirá crear tensores.
import torch.nn as nn # torch.nn nos permite crear una red neuronal.
import torch.nn.functional as F # nn.functional nos da acceso a las funciones de activación y pérdida.
from torch.optim import Adam # optim contiene muchos optimizadores. Esta vez estamos usando Adam
import lightning as L # lightning tiene toneladas de herramientas geniales que facilitan las redes neuronales
from torch.utils.data import TensorDataset, DataLoader # estos son necesarios para los datos de entrenamiento

from pytorch_lightning.utilities.seed import seed_everything
# Construir una unidad de memoria a largo plazo a mano usando PyTorch + Lightning
# construir una red neuronal y una unidad de memoria a corto plazo (LSTM) es un tipo de red neuronal, significa que necesitamos
# crear una nueva clase. Para facilitar el entrenamiento del LSTM, esta clase se heredará de `LightningModule` y crearemos los siguientes
# métodos:
# - `__init__()` para inicializar los pesos y sesgos y realizar un seguimiento de algunas otras cosas de mantenimiento de la casa.
# - `lstm_unit()` para hacer los cálculos de LSTM. Por ejemplo, para calcular el porcentaje de la memoria a largo plazo para recordar.
# - `forward()` para hacer un pase hacia adelante a través del LSTM desarrollado. En otras palabras, `forward()` llama a `lstm_unit()`
#    para cada punto de datos.
# - `configure_optimizers()` para configurar el optimizador. En el pasado, usamos `SGD` (descenso de gradiente estocástico),
#    sin embargo, en este ejercicio cambiaremos las cosas y usaremos `Adam`, otro algoritmo popular para optimizar los pesos y sesgos.
# - `training_step()` para pasar los datos de entrenamiento a `forward()`, calcular la pérdida y realizar un seguimiento de los valores de pérdida en un archivo de registro".
# Aquí estamos implementando una red LSTM a mano...
class LSTMbyHand(L.LightningModule):
    def __init__(self):
        super().__init__()
# Lo primero que hacemos es establecer la semilla para el generador de números aleatorios.
# Esto asegura que cuando alguien crea un modelo de esta clase, ese modelo
# comenzará exactamente con los mismos números aleatorios
        seed_everything(seed=42)
# Inicializa los tensores para el LSTM
# NOTA: nn.LSTM() usa valores aleatorios de una distribución uniforme para inicializar los tensores
# Aquí podemos hacerlo de 2 maneras diferentes 1) Distribución normal y 2) Distribución uniforme
# Comenzaremos con la Distribución Normal
        mean = torch.tensor(0.0)
        std = torch.tensor(1.0)
# NOTA: En este caso, solo estoy usando la distribución normal para los Pesos.
# Todos los sesgos se inicializan en 0.
# Estos son los Pesos y Sesgos en la primera etapa, que determina qué porcentaje
# de la memoria a largo plazo que recordará la unidad LSTM.
        self.wlr1 = nn.Parameter(torch.normal(mean=mean, std=std), requires_grad=True)
        self.wlr2 = nn.Parameter(torch.normal(mean=mean, std=std), requires_grad=True)
        self.blr1 = nn.Parameter(torch.tensor(0.), requires_grad=True)
    # Estos son los pesos y sesgos en la segunda etapa, que determina la nueva
    # memoria potencial a largo plazo y qué porcentaje se recordará.
        self.wpr1 = nn.Parameter(torch.normal(mean=mean, std=std), requires_grad=True)
        self.wpr2 = nn.Parameter(torch.normal(mean=mean, std=std), requires_grad=True)
        self.bpr1 = nn.Parameter(torch.tensor(0.), requires_grad=True)

        self.wp1 = nn.Parameter(torch.normal(mean=mean, std=std), requires_grad=True)
        self.wp2 = nn.Parameter(torch.normal(mean=mean, std=std), requires_grad=True)
        self.bp1 = nn.Parameter(torch.tensor(0.), requires_grad=True)
# Estos son los Pesos y Sesgos en la tercera etapa, que determina el
# nueva memoria a corto plazo y qué porcentaje se enviará a la salida.
        self.wo1 = nn.Parameter(torch.normal(mean=mean, std=std), requires_grad=True)
        self.wo2 = nn.Parameter(torch.normal(mean=mean, std=std), requires_grad=True)
        self.bo1 = nn.Parameter(torch.tensor(0.), requires_grad=True)
# También podemos inicializar todos los Pesos y Sesgos usando una distribución uniforme. Esto es
# cómo lo hace nn.LSTM().
        self.wlr1 = nn.Parameter(torch.rand(1), requires_grad=True)
        self.wlr2 = nn.Parameter(torch.rand(1), requires_grad=True)
        self.blr1 = nn.Parameter(torch.rand(1), requires_grad=True)
        self.wpr1 = nn.Parameter(torch.rand(1), requires_grad=True)
        self.wpr2 = nn.Parameter(torch.rand(1), requires_grad=True)
        self.bpr1 = nn.Parameter(torch.rand(1), requires_grad=True)

        self.wp1 = nn.Parameter(torch.rand(1), requires_grad=True)
        self.wp2 = nn.Parameter(torch.rand(1), requires_grad=True)
        self.bp1 = nn.Parameter(torch.rand(1), requires_grad=True)

        self.wo1 = nn.Parameter(torch.rand(1), requires_grad=True)
        self.wo2 = nn.Parameter(torch.rand(1), requires_grad=True)
        self.bo1 = nn.Parameter(torch.rand(1), requires_grad=True)
    def lstm_unit(self, input_value, long_memory, short_memory):
# lstm_unit hace los cálculos para una sola unidad LSTM.
# NOTAS:
# la memoria a largo plazo también se llama "estado celular"
# la memoria a corto plazo también se llama "estado oculto"
# 1) La primera etapa determina qué porcentaje de la memoria a largo plazo actual
# debe ser recordado
        long_remember_percent = torch.sigmoid((short_memory * self.wlr1) +
                                                  (input_value * self.wlr2) +
                                                  self.blr1)
# 2) La segunda etapa crea una nueva memoria potencial a largo plazo y determina qué
# porcentaje de eso para agregar a la memoria a largo plazo actual
        potential_remember_percent = torch.sigmoid((short_memory * self.wpr1) +
                                                       (input_value * self.wpr2) +
                                                       self.bpr1)
        potential_memory = torch.tanh((short_memory * self.wp1) +
                                          (input_value * self.wp2) +
                                          self.bp1)
# Una vez que hayamos pasado por las dos primeras etapas, podemos actualizar la memoria a largo plazo
        updated_long_memory = ((long_memory * long_remember_percent) +
                           (potential_remember_percent * potential_memory))
# 3) La tercera etapa crea una nueva memoria potencial a corto plazo y determina qué
# porcentaje de eso debe recordarse y usarse como salida.
        output_percent = torch.sigmoid((short_memory * self.wo1) +
                                           (input_value * self.wo2) +
                                           self.bo1)
        updated_short_memory = torch.tanh(updated_long_memory) * output_percent
# Finalmente, devolvemos las memorias actualizadas a largo y corto plazo.
        return([updated_long_memory, updated_short_memory])
    def forward(self, input):
# forward() desenrolla el LSTM para los datos de entrenamiento llamando a lstm_unit() para cada día de datos de entrenamiento que tenemos
# forward() también realiza un seguimiento de los recuerdos a largo y corto plazo después de cada día y regresa
# la memoria final a corto plazo, que es la 'salida' de la LSTM.
        long_memory = 0 # la memoria a largo plazo también se denomina \"estado celular\" y se indexa con c0, c1, ..., cN
        short_memory = 0 # la memoria a corto plazo también se denomina \"estado oculto\" y está indexada con h0, h1, ..., cNN
        day1 = input[0]
        day2 = input[1]
        day3 = input[2]
        day4 = input[3]
# Día 1
        long_memory, short_memory = self.lstm_unit(day1, long_memory, short_memory)
# Día 2
        long_memory, short_memory = self.lstm_unit(day2, long_memory, short_memory)
# Día 3
        long_memory, short_memory = self.lstm_unit(day3, long_memory, short_memory)
# Día 4
        long_memory, short_memory = self.lstm_unit(day4, long_memory, short_memory)
#Ahora devuelve short_memory, que es la 'salida' del LSTM.
        return short_memory
    def configure_optimizers(self): # esto configura el optimizador que queremos usar para la retropropagación.
             return Adam(self.parameters(), lr=0.1) ## NOTA: Establecer la tasa de aprendizaje en 0.1 entrena mucho más rápido que
                                                      ## usando la tasa de aprendizaje predeterminada, lr=0.001, que requiere mucho más
                                                      ## capacitación. Sin embargo, si usamos el valor predeterminado, obtenemos
                                                      ## exactamente los mismos pesos y sesgos que usó el autor en
                                                      ## el video LSTM claramente explicado de StatQuest. Así que usaremos el
                                                      ## valor por defecto.
             return Adam(self.parameters())
    def training_step(self, batch, batch_idx): #dar un paso durante el descenso de pendiente.
            input_i, label_i = batch #recopilar entrada
            output_i = self.forward(input_i[0]) #ejecutar la entrada a través de la red neuronal
            loss = (output_i - label_i)**2 #pérdida = residual al cuadrado
            ###################
            ## Registrando la pérdida y los valores predichos para que podamos evaluar el entrenamiento
            ###################
            self.log("train_loss", loss)
            # NOTA: Nuestro conjunto de datos consta de dos secuencias de valores que representan a la empresa A y la empresa B
            # Para la empresa A, el objetivo es predecir que el valor del día 5 = 0, y para la empresa B,
            # el objetivo es predecir que el valor en el Día 5 = 1. Usamos label_i, el valor que queremos
            # predecir, para realizar un seguimiento de la empresa para la que acabamos de hacer una predicción y
            # registrar ese valor de salida en un archivo específico de la empresa
            if (label_i == 0):
                self.log("out_0", output_i)
            else:
                self.log("out_1", output_i)

            return loss