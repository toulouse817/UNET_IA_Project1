#Asignatura: IA
#Elaborado por: Gabriel Ramírez
#11/02/2023

#Basado en el script creado por  Joshua Starmer en el tutorial Gran memoria a largo plazo (LSTM) con PyTorch + Lightning https://youtu.be/RHGiXPuo_pI

#NOTA: Este script utiliza La Programación Orientada a Objetos (POO u OOP según sus siglas en inglés) como paradigma de programación que usa objetos y sus interacciones para diseñar aplicaciones y programas
#En el script se pueden encontrar definición de Clases (usando la palabra reservada class), Objetos como instancias  model = BasicNN() y Métodos usando la palabra reservada def

#Importar los módulos que harán todo el trabajo
import torch # torch nos permitirá crear tensores.
import torch.nn as nn # torch.nn nos permite crear una red neuronal.
import torch.nn.functional as F # nn.functional nos da acceso a las funciones de activación y pérdida.
from torch.optim import Adam # optim contiene muchos optimizadores. Esta vez estamos usando Adam
import lightning as L # lightning tiene toneladas de herramientas geniales que facilitan las redes neuronales
from torch.utils.data import TensorDataset, DataLoader # estos son necesarios para los datos de entrenamiento

from pytorch_lightning.utilities.seed import seed_everything
#En lugar de codificar un LSTM a mano, veamos qué podemos hacer con nn.LSTM() de PyTorch
class LightningLSTM(L.LightningModule):
            def __init__(self): # __init__() is the class constructor function, and we use it to initialize the Weights and Biases.
                super().__init__() # initialize an instance of the parent class, LightningModule.
                seed_everything(seed=42)
                ## input_size = número de características (o variables) en los datos. En nuestro ejemplo
                ##              solo tenemos una sola característica (valor)
                ## hidden_size = determina la dimensión de la salida
                ##               en otras palabras, si establecemos hidden_size=1, entonces tenemos 1 nodo de salida
                ##               si configuramos hidden_size=50, entonces tenemos 50 nodos de salida (que luego pueden ser 50 de entrada
                ##               nodos a una red neuronal posterior completamente conectada.
                self.lstm = nn.LSTM(input_size=1, hidden_size=1)
            def forward(self, input):
## transponer el vector de entrada
                input_trans = input.view(len(input), 1)
                lstm_out, temp = self.lstm(input_trans)
## lstm_out tiene memorias a corto plazo para todas las entradas. Hacemos nuestra predicción con el último.
                prediction = lstm_out[-1]
                return prediction
            def configure_optimizers(self): # esto configura el optimizador que queremos usar para la retropropagación.
                return Adam(self.parameters(), lr=0.1) # simplemente seguiremos adelante y estableceremos la tasa de aprendizaje en 0.1
            def training_step(self, batch, batch_idx): # dar un paso durante el descenso de pendiente.
                input_i, label_i = batch # recopilar entrada
                output_i = self.forward(input_i[0]) # ejecutar la entrada a través de la red neuronal
                loss = (output_i - label_i)**2 ## pérdida = residual al cuadrado
            ###################
            ## Registrando la pérdida y los valores predichos para que podamos evaluar el entrenamiento
            ###################
                self.log("train_loss", loss)
                if (label_i == 0):
                    self.log("out_0", output_i)
                else:
                    self.log("out_1", output_i)
                return loss