#Asignatura: IA
#Elaborado por: Gabriel Ramírez
#11/02/2023

#Basado en el script creado por  Joshua Starmer en el tutorial The StatQuest Introducción a la codificación de redes neuronales con PyTorch y Lightning https://youtu.be/khMzi6xPbuM

#NOTA: Este script utiliza La Programación Orientada a Objetos (POO u OOP según sus siglas en inglés) como paradigma de programación que usa objetos y sus interacciones para diseñar aplicaciones y programas
#En el script se pueden encontrar definición de Clases (usando la palabra reservada class), Objetos como instancias  model = BasicNN() y Métodos usando la palabra reservada def

import torch # torch nos permitirá crear tensores.
import torch.nn as nn # torch.nn nos permite crear una red neuronal.
import torch.nn.functional as F # nn.funcional nos da acceso a las funciones de activación y pérdida.
from torch.optim import SGD # optim contiene muchos optimizadores. Aquí, estamos usando SGD, descenso de gradiente estocástico.

import lightning as L # lightning tiene toneladas de herramientas geniales que facilitan las redes neuronales
from torch.utils.data import TensorDataset, DataLoader # estos son necesarios para los datos de entrenamiento

import matplotlib.pyplot as plt ## matplotlib nos permite dibujar gráficos.
import seaborn as sns ## seaborn hace que sea más fácil dibujar gráficos atractivos.

from pytorch_lightning.utilities.seed import seed_everything # esto se agrega para evitar que en diferentes computadoras se
seed_everything(seed=42)                                     # obtengan diferentes resultados.
    # Cree una red neuronal simple en PyTorch
##Al igual que construir una red neuronal ***preentrenada*** en **PyTorch**,
# construir una red neuronal ***preentrenada*** con **PyTorch + Lightning**
# significa crear una nueva clase con dos métodos:
# `__init__()` y `forward()`. El método `__init__()` define e inicializa todos los parámetros que queremos usar,
# y el método `forward()` le dice a **PyTorch + Lightning** lo que debería suceder durante un pase directo a través de la red neuronal.


class BasicLightningTrain(L.LightningModule):
    def __init__(
            self):  # __init__() es la función constructora de clases, y la usamos para inicializar los pesos y sesgos. norte",
        # NOTA: El código para __init__ () es el mismo que antes excepto que ahora tenemos un parámetro de tasa de aprendizaje (para
        # gradiente de descenso) y modificamos final_bias de dos maneras:
        # 1) ponemos el valor del tensor a 0, y
        # 2) establecemos "requires_grad=True
        super().__init__()  # inicializa una instancia de la clase principal, LightningModule
        self.w00 = nn.Parameter(torch.tensor(1.7), requires_grad=False)
        self.b00 = nn.Parameter(torch.tensor(-0.85), requires_grad=False)
        self.w01 = nn.Parameter(torch.tensor(-40.8), requires_grad=False)
        self.w10 = nn.Parameter(torch.tensor(12.6), requires_grad=False)
        self.b10 = nn.Parameter(torch.tensor(0.0), requires_grad=False)
        self.w11 = nn.Parameter(torch.tensor(2.7), requires_grad=False)
        # Queremos modificar final_bias para demostrar cómo optimizarlo con backpropagation.
        # NOTA: El valor óptimo para final_bias es -16...
        # self.final_bias = nn.Parameter(torch.tensor(-16.), requires_grad=False)
        # ...así que lo establecemos en 0 y le decimos a Pytorch que ahora necesita calcular el gradiente para este parámetro
        self.final_bias = nn.Parameter(torch.tensor(0.0), requires_grad=True)
        self.learning_rate = 0.01  # esto es para descenso de gradiente. NOTA: mejoraremos este valor más adelante, así que, técnicamente
        # esto es solo un marcador de posición hasta entonces. En otras palabras, podríamos poner cualquier valor aquí
        # porque luego lo reemplazaremos con el valor mejorado

    def forward(self, input):
        ## forward() es exactamente igual que antes
        input_to_top_relu = input * self.w00 + self.b00
        top_relu_output = F.relu(input_to_top_relu)
        scaled_top_relu_output = top_relu_output * self.w01
        input_to_bottom_relu = input * self.w10 + self.b10
        bottom_relu_output = F.relu(input_to_bottom_relu)
        scaled_bottom_relu_output = bottom_relu_output * self.w11
        input_to_final_relu = (scaled_top_relu_output
                               + scaled_bottom_relu_output
                               + self.final_bias)
        output = F.relu(input_to_final_relu)
        return output  # output es la eficacia prevista para una dosis de fármaco

    def configure_optimizers(self):  # esto configura el optimizador que queremos usar para retropropagación
        return SGD(self.parameters(),
                   lr=self.learning_rate)  # NOTA: Establecemos la tasa de aprendizaje (lr) en nuestra nueva variable
        # self.learning_rate

    def training_step(self, batch, batch_idx):  # dar un paso durante el descenso de pendiente.
        # NOTA: Cuando se llama a training_step(), calcula la pérdida con el siguiente código...
        input_i, label_i = batch  # recopilar entrada
        output_i = self.forward(input_i)  # ejecutar la entrada a través de la red neuronal
        loss = (output_i - label_i) ** 2  # loss = residual al cuadrado
        # ..antes de llamar (internamente y detrás de escena)...
        # optimizer.zero_grad() # para borrar gradientes
        # loss.backward()       # para hacer la retropropagación
        # optimizer.step()      # para actualizar los parámetros
        return loss