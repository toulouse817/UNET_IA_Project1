# Asignatura: IA
# Elaborado por: Gabriel Ramírez
# 11/02/2023

# Basado en el script creado por  Joshua Starmer en el tutorial The StatQuest Introduction to PyTorch https://youtu.be/FHdlXe1bSe4

# NOTA: Este script utiliza La Programación Orientada a Objetos (POO u OOP según sus siglas en inglés) como paradigma de programación que usa objetos y sus interacciones para diseñar aplicaciones y programas
# En el script se pueden encontrar definición de Clases (usando la palabra reservada class), Objetos como instancias  model = BasicNN() y Métodos usando la palabra reservada def

# Se utilizó  **[PyTorch](https://pytorch.org/)** para crear, graficar la salida y optimizar (entrenar) la red neural explicada en StatQuest's **[Neural Networks Part 3: ReLU in Action!!!](https://youtu.be/68BZ5f7P94E)** Esta red neural simple, vista a continuación predice si una dosis de medicamento será efectiva o no.
# Los datos de entrenamiento a los cuales se ajusta la red neural está conformado por 3 diferentes valores de dosis de medicamento. Las dosis baja (0) y dosis alta (1) no curan una enfermedad, por lo que sus valores en el eje y son ambos 0. Sin embargo cuando la dosis es 0.5, esa dosis puede curar la enfermedad, y el valor del eje y correspondiene es 1.
# A continuación, vemos la salida de la red neuronal para diferentes dosis.

# Importación de módulos con funcionalidades especiales para crear m graficar y optimizar redes neurales en Python
import torch  # torch es el nombre a usar para el modulo de PyTorch, proporciona funciones básicas, desde establecer
# una semilla aleatoria (para reproducibilidad) hasta crear tensores.
import torch.nn as nn  # torch.nn  permite crear una red neuronal.
import torch.nn.functional as F  # nn.functional nos da acceso a las funciones de activación y pérdida.
from torch.optim import SGD  # optim contiene muchos optimizadores. Se usará SGD, descenso de gradiente estocástico.
import matplotlib.pyplot as plt  ## matplotlib nos permite dibujar gráficos.
import seaborn as sns  ## seaborn hace que sea más fácil dibujar gráficos atractivos.


# Crear una red neurarl en PyTorch
# Construir una red neuronal en PyTorch significa crear una nueva clase con dos métodos: `__init__()` y `forward()`.
# El método `__init__()` define e inicializa todos los parámetros que queremos usar,
# y el método `forward()` le dice a PyTorch lo que debería suceder durante un paso directo a través de la red neuronal.

# crear una clase de red neuronal creando una clase que herede de nn.Module.
class BasicNN(nn.Module):

    def __init__(
            self):  # __init__() es la función constructora de clases, y la usamos para inicializar los pesos y sesgos.

        super().__init__()  # inicializa una instancia de la clase principal, nn.Model.

        # Ahora se crea los pesos y sesgos para la red neuronal.
        # Cada peso o sesgo es un nn.Parámetro, lo que nos da la opción de optimizar el parámetro configurando
        # require_grad, que es la abreviatura de "requiere gradiente", a True. Ya que no necesitamos optimizar ninguno de estos
        # parámetros ahora, establecemos require_grad=False.
        #
        # NOTA: Debido a que nuestra red neuronal ya se ajusta a los datos, ingresaremos valores específicos
        # para cada peso y sesgo. Por el contrario, si no hubiéramos ajustado ya la red neuronal a los datos,
        # podríamos comenzar con una inicialización aleatoria de los pesos y sesgos.
        self.w00 = nn.Parameter(torch.tensor(1.7), requires_grad=False)
        self.b00 = nn.Parameter(torch.tensor(-0.85), requires_grad=False)
        self.w01 = nn.Parameter(torch.tensor(-40.8), requires_grad=False)

        self.w10 = nn.Parameter(torch.tensor(12.6), requires_grad=False)
        self.b10 = nn.Parameter(torch.tensor(0.0), requires_grad=False)
        self.w11 = nn.Parameter(torch.tensor(2.7), requires_grad=False)

        self.final_bias = nn.Parameter(torch.tensor(-16.), requires_grad=False)

    def forward(self, input):  # forward() toma un valor de entrada y lo ejecuta a través de la red neuronal

        # Las siguientes tres líneas implementan la parte "superior" de la red neuronal (usando el nodo superior en la capa oculta).
        input_to_top_relu = input * self.w00 + self.b00
        top_relu_output = F.relu(input_to_top_relu)
        scaled_top_relu_output = top_relu_output * self.w01

        # Las siguientes tres líneas implementan la parte "inferior" de la red neuronal (usando el nodo inferior en la capa oculta).
        input_to_bottom_relu = input * self.w10 + self.b10
        bottom_relu_output = F.relu(input_to_bottom_relu)
        scaled_bottom_relu_output = bottom_relu_output * self.w11

        # Aquí, combinamos los nodos superior e inferior de la capa oculta con el sesgo final.
        input_to_final_relu = scaled_top_relu_output + scaled_bottom_relu_output + self.final_bias

        output = F.relu(input_to_final_relu)

        return output  # la salida es la Eficacia prevista para una dosis de fármaco.