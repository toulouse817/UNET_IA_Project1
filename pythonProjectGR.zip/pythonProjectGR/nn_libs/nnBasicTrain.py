#Asignatura: IA
#Elaborado por: Gabriel Ramírez
#11/02/2023
# Importación de módulos con funcionalidades especiales para crear m graficar y optimizar redes neurales en Python
import torch  # torch es el nombre a usar para el modulo de PyTorch, proporciona funciones básicas, desde establecer
# una semilla aleatoria (para reproducibilidad) hasta crear tensores.
import torch.nn as nn  # torch.nn  permite crear una red neuronal.
import torch.nn.functional as F  # nn.functional nos da acceso a las funciones de activación y pérdida.
from torch.optim import SGD  # optim contiene muchos optimizadores. Se usará SGD, descenso de gradiente estocástico.
import matplotlib.pyplot as plt  ## matplotlib nos permite dibujar gráficos.
import seaborn as sns  ## seaborn hace que sea más fácil dibujar gráficos atractivos.
# El gráfico muestra que la red neuronal se ajusta a los datos de entrenamiento. En otras palabras, hasta ahora,
# no tenemos ningún error en el código.

# Optimizar (entrenar) un parámetro en la red neuronal y graficar la salida
# Ahora que sabemos cómo crear y usar una red neuronal simple, y podemos graficar la salida en relación con la entrada,
# veamos cómo entrenar una red neuronal. Lo primero que debemos hacer es decirle a PyTorch qué parámetro (o parámetros)
# queremos entrenar, y lo hacemos configurando `requires_grad=True`. En este ejemplo, entrenaremos `final_bias`.

# crear una red neuronal creando una clase que herede de nn.Module.
# NOTA: Este código es el mismo que antes, excepto que cambiamos el nombre de la clase a BasicNN_train y modificamos
# final_bias de dos maneras:
# 1) ponemos el valor del tensor a 0, y
# 2) configuramos "requires_grad=True".
class BasicNN_train(nn.Module):
    def __init__(
            self):  # __init__ es la función constructora de clases, y la usamos para inicializar los pesos y sesgos.
        super().__init__()  # inicializa una instancia de la clase principal, nn.Module.
        self.w00 = nn.Parameter(torch.tensor(1.7), requires_grad=False)
        self.b00 = nn.Parameter(torch.tensor(-0.85), requires_grad=False)
        self.w01 = nn.Parameter(torch.tensor(-40.8), requires_grad=False)

        self.w10 = nn.Parameter(torch.tensor(12.6), requires_grad=False)
        self.b10 = nn.Parameter(torch.tensor(0.0), requires_grad=False)
        self.w11 = nn.Parameter(torch.tensor(2.7), requires_grad=False)
        # queremos modificar final_bias para demostrar cómo optimizarlo con backpropagation.
        # El valor óptimo para final_bias es -16...
        # self.final_bias = nn.Parameter(antorcha.tensor(-16.), require_grad=False)
        # ...así que lo establecemos en 0 y le decimos a Pytorch que ahora necesita calcular el gradiente para este parámetro.
        self.final_bias = nn.Parameter(torch.tensor(0.), requires_grad=True)

    def forward(self, input):
        input_to_top_relu = input * self.w00 + self.b00
        top_relu_output = F.relu(input_to_top_relu)
        scaled_top_relu_output = top_relu_output * self.w01

        input_to_bottom_relu = input * self.w10 + self.b10
        bottom_relu_output = F.relu(input_to_bottom_relu)
        scaled_bottom_relu_output = bottom_relu_output * self.w11

        input_to_final_relu = scaled_top_relu_output + scaled_bottom_relu_output + self.final_bias

        output = F.relu(input_to_final_relu)

        return output

